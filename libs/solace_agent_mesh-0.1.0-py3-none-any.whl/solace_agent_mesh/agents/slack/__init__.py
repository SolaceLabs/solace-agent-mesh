"""Slack agent package."""
