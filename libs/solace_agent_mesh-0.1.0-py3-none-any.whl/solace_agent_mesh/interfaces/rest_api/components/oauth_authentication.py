import os
import requests
from flask import request, redirect, session
from requests_oauthlib import OAuth2Session
from solace_ai_connector.common.log import log
from solace_ai_connector_rest.components.rest_base import RestBase, info as base_info
from solace_ai_connector_rest.components.utils import create_api_response

# Clone and modify the info dictionary
info = base_info.copy()
info.update(
    {
        "class_name": "OauthAuthentication",
        "description": "This component simulates an authentication server that handles user authentication.",
    }
)
info["config_parameters"].extend(
    [
        {
            "name": "oauth_authentication",
            "type": "object",
            "properties": {
                "provider": {"type": "string"},
                "client_id": {"type": "string"},
                "client_secret": {"type": "string"},
                "https_cert": {"type": "string"},
                "https_key": {"type": "string"},
                "tenant_id": {"type": "string"},
                "enabled": {"type": "boolean"},
            },
            "description": "Oauth2 Authentication configuration parameters.",
        },
    ],
)


class OauthAuthentication(RestBase):
    """This component simulates an authentication server that authenticate a user."""
    
    TOKEN_VALIDATION_ERROR = "Token validation failed"
    TOKEN_VALIDATION_ERROR_LOG = "Error in token validation: %s"

    def __init__(self, **kwargs):
        super().__init__(**kwargs)
        self.app.secret_key = os.urandom(24)
        self.listen_port = self.get_config("listen_port", 8000)
        # prevent oauthlib to change the scope
        os.environ["OAUTHLIB_RELAX_TOKEN_SCOPE"] = "1"


    def run(self):
        if self.oauth_enabled:
            _cert = self.get_config("https_cert", None)
            _key = self.get_config("https_key", None)
            ssl_context = (_cert, _key) if _cert and _key else None
            try:
                self.app.run(host=self.host, port=self.listen_port, ssl_context=ssl_context)
            except Exception as e:
                log.error("Error in running the server: %s", e)
        else:
            try:
                # Release resources
                self.cleanup()
            except Exception as e:
                pass

    def stop_component(self):
        func = self.app.config.get("werkzeug.server.shutdown")
        if func:
            func()

        # Clear the input queue
        with self.input_queue.mutex:
            self.input_queue.queue.clear()

    def get_access_token(self, request):
        """Get the access token from the request headers."""
        auth_header = request.headers.get("Authorization")
        if not auth_header or not auth_header.startswith("Bearer "):
            return create_api_response("No token provided", 400)
        auth_split = auth_header.split("Bearer ")
        if len(auth_split) != 2:
            return create_api_response("Token is invalid", 400)

        access_token = auth_split[1]
        return access_token

    def register_routes(self):
        """Register the routes for the authentication server."""

        self.oauth_enabled = self.get_config("enabled", False)
        if self.oauth_enabled:
            self.register_auth_routes()

    def register_auth_routes(self):
        self.provider = self.get_config("provider")
        self.client_id = self.get_config("client_id")
        self.client_secret = self.get_config("client_secret")
        self.default_redirect_uri = self.get_config("redirect_uri")

        self._configure_auth_provider()

        @self.app.route("/login", methods=["GET"])
        def login():
            """
            Login handler for the OAuth 2 authorization flow.

            This endpoint initiates the OAuth 2 authorization flow by redirecting the user to the OAuth
            provider's authorization URL. The user will be prompted to authorize the application, and
            upon successful authorization, the OAuth provider will redirect the user back to the callback
            URL with an authorization code.

            Steps:
                1. Create an OAuth2Session with the client ID, redirect URI, and scope.
                2. Generate the authorization URL using the authorization_url method.
                3. Store the state in the session to protect against CSRF attacks.
                4. Redirect the user to the authorization URL.

            Query Parameters:
                redirect_uri (str, optional): Override the default redirect URI for this login request
            Responses:
                Redirects the user to the OAuth provider's authorization URL.

            Returns:
                Response: A Flask response object that redirects the user to the OAuth provider's authorization URL.
            """
            redirect_uri = request.args.get('redirect_uri')

            # Use provided redirect_uri if present, otherwise use default
            current_redirect_uri = redirect_uri or self.default_redirect_uri
            
            client = OAuth2Session(
                client_id=self.client_id,
                redirect_uri=current_redirect_uri,
                scope=self.scope,
            )

            authorization_url, state = client.authorization_url(
                self.auth_base_url, access_type="offline", prompt=self.prompt
            )
            session["oauth_state"] = state
            # Store the redirect_uri in session for callback verification
            session["redirect_uri"] = current_redirect_uri
            return redirect(authorization_url)

        @self.app.route("/callback", methods=["GET"])
        def handle_callback():
            """
            Callback handler for the OAuth 2 authorization flow.

            This endpoint handles the callback from the OAuth 2 provider after the user has authorized
            the application. It exchanges the authorization code for an access token and stores the token
            in the session.

            Steps:
                1. Create an OAuth2Session with the client ID, redirect URI, and state from the session.
                2. Exchange the authorization code for an access token using the fetch_token method.
                3. Store the access token in the session.
                4. Return a response with the token data if successful.

            Responses:
                200 OK: The token was successfully obtained and stored in the session. The response will include the token data.
                401 Unauthorized: An error occurred during the token exchange process. The response will include an error message.

            Returns:
                Response: A Flask response object containing the token data or an error message.
            """
            try:
                # Use the redirect_uri that was stored during login
                stored_redirect_uri = session.get("redirect_uri", self.default_redirect_uri)

                client = OAuth2Session(
                    client_id=self.client_id,
                    redirect_uri=stored_redirect_uri,
                    state=session["oauth_state"],
                )

                token = client.fetch_token(
                    self.token_url,
                    authorization_response=request.url,
                    client_secret=self.client_secret,
                )
                session["oauth_token"] = token
                return create_api_response(token, 200)
            except Exception as e:
                log.error("Error in handle_callback: %s", e)
                return create_api_response("Login callback failed", 401)

        @self.app.route("/refresh_token", methods=["POST"])
        def refresh_token():
            """
            Refresh an OAuth 2 token using a refresh token.

            This endpoint allows clients to refresh their OAuth 2 access token using a refresh token.
            The client must provide a valid refresh token in the request body. The endpoint will
            return a new access token and refresh token if the refresh operation is successful.

            Request Body:
                refresh_token (str): A string containing the refresh token.

            Example Request Body:
            {
                {
                    "refresh_token": "your-refresh-token",
                }
            }

            Responses:
                200 OK: The token was successfully refreshed. The response will include the new token data.
                400 Bad Request: The request was invalid or the token was not provided.
                500 Internal Server Error: An error occurred while processing the request.

            Returns:
                Response: A Flask response object containing the new token data or an error message.
            """

            access_token = self.get_access_token(request)

            refresh_token = request.json.get("refresh_token")
            if not refresh_token:
                return create_api_response("No refresh token provided", 400)

            token = {
                "id_token": access_token,
                "refresh_token": refresh_token,
            }

            extra = {
                "client_id": self.client_id,
                "client_secret": self.client_secret,
            }

            try:
                client = OAuth2Session(
                    self.client_id,
                    token=token,
                )
                new_token = client.refresh_token(self.refresh_url, **extra)
                if new_token:
                    session["oauth_token"] = new_token
                    access_token = new_token.get("access_token")
                return create_api_response(access_token, 200)
            except Exception as e:
                log.error("Error in refresh_token: %s", e)
                return create_api_response(
                    "Token refresh failed. Please check the token format.", 400
                )

        @self.app.route("/user_info", methods=["GET"])
        def get_user_info():
            """
            Retrieve user information from the OAuth provider.

            Example Response:
            {
                "email": "sample@gmail.com"
                "user_id": "1730904645",
            }

            Responses:
                200 OK: The token was successfully validated. The response will include the token information.
                400 Bad Request: The request was invalid or the token was not provided.
                404 Not Found: The user information was not found.

            Returns:
                Response: A Flask response object containing the token information or an error message.
            """
            access_token = self.get_access_token(request)

            try:
                # google user info
                if self.provider.lower() == "google":
                    return self._get_google_user_info(access_token)
                # azure user info
                elif self.provider.lower() == "azure":
                    return self._get_azure_user_info(access_token)
                else:
                    return create_api_response("Unsupported provider", 400)
            except Exception as e:
                log.error(self.TOKEN_VALIDATION_ERROR_LOG, e)
                return create_api_response(self.TOKEN_VALIDATION_ERROR, 400)

        @self.app.route("/is_token_valid", methods=["POST"])
        def is_token_valid():
            """
            Check if an OAuth 2 token is valid.

            This endpoint checks if the provided OAuth 2 token is valid by making a request to the validation URL.
            If the token is expired, it will return False.

            Request Body:
                token (str): The access token to validate.

            Example Request Body:
            {
                "token": "your-access-token"
            }

            Example Response:
            {
                "valid": True
            }

            Responses:
                200 OK: The token was successfully validated. The response will include the validation result.
                400 Bad Request: The request was invalid or the token was not provided.
                401 Unauthorized: The token has expired.

            Returns:
                Response: A Flask response object containing the validation result or an error message.
            """
            access_token = self.get_access_token(request)

            try:
                # google token validation
                if self.provider.lower() == "google":
                    try:
                        response = requests.get(self.validate_url + access_token)
                        if response.status_code == 200:
                            return create_api_response("Token is valid", 200)
                        elif response.status_code == 401:  # Token expired
                            return create_api_response(
                                "Token has been expired. Please renew the token.", 401
                            )
                        else:
                            return create_api_response(
                                self.TOKEN_VALIDATION_ERROR, response.status_code
                            )
                    except Exception as e:
                        log.error(self.TOKEN_VALIDATION_ERROR_LOG, e)
                        return create_api_response(self.TOKEN_VALIDATION_ERROR, 400)
                # azure token validation
                elif self.provider.lower() == "azure":
                    headers = {"Authorization": f"Bearer {access_token}"}
                    response = requests.get(self.validate_url, headers=headers)

                    if response.status_code == 200:
                        return create_api_response("Token is valid", 200)
                    elif response.status_code == 401:  # Token expired
                        return create_api_response(
                            "Token has been expired. Please renew the token.", 401
                        )
                    else:
                        return create_api_response(
                            self.TOKEN_VALIDATION_ERROR, response.status_code
                        )
                else:
                    return create_api_response("Unsupported provider", 400)
            except Exception as e:
                log.error(self.TOKEN_VALIDATION_ERROR_LOG, e)
                return create_api_response(self.TOKEN_VALIDATION_ERROR, 400)

    def _configure_auth_provider(self):
        match self.provider.lower():
            case "google":
                # Note: Set the redirect URI in Google Cloud Console as well
                self.auth_base_url = "https://accounts.google.com/o/oauth2/auth"
                self.token_url = "https://accounts.google.com/o/oauth2/token"
                self.refresh_url = "https://accounts.google.com/o/oauth2/token"
                self.validate_url = (
                    "https://www.googleapis.com/oauth2/v1/tokeninfo?access_token="
                )
                self.scope = [
                    "https://www.googleapis.com/auth/userinfo.email",
                    "https://www.googleapis.com/auth/userinfo.profile",
                ]
                self.prompt = "consent"
            case "azure":
                tenant_id = self.get_config("tenant_id")
                self.auth_base_url = f"https://login.microsoftonline.com/{tenant_id}/oauth2/V2.0/authorize"
                self.token_url = (
                    f"https://login.microsoftonline.com/{tenant_id}/oauth2/V2.0/token"
                )
                self.refresh_url = (
                    f"https://login.microsoftonline.com/{tenant_id}/oauth2/token"
                )
                self.validate_url = "https://graph.microsoft.com/v1.0/me"
                self.scope = [
                    "https://graph.microsoft.com/.default",
                    "openid",
                    "offline_access",
                ]
                self.prompt = "select_account"
            case _:
                raise ValueError("Authentication service provider not supported")
    
    def _get_google_user_info(self, access_token):
        response = requests.get(
            self.validate_url + access_token,
        )

        if response.status_code == 200:
            data = response.json()
            email = data.get("email")
            user_id = data.get("user_id")
            return create_api_response(
                {"email": email, "user_id": user_id}, 200
            )
        else:
            return create_api_response(
                "User info not found", response.status_code
            )

    def _get_azure_user_info(self, access_token):
        headers = {"Authorization": f"Bearer {access_token}"}
        response = requests.get(self.validate_url, headers=headers)

        if response.status_code == 200:
            user_info = response.json()
            return create_api_response(
                {
                    "email": user_info.get("mail", "Unknown"),
                    "user_id": user_info.get(
                        "userPrincipalName", "Unknown"
                    ),
                },
                200,
            )
        else:
            return create_api_response(
                "User info not found", response.status_code
            )

