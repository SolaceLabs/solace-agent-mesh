"""MS Graph utilities to get user role assignments"""

import datetime
import asyncio

from azure.identity import ClientSecretCredential
from msgraph import GraphServiceClient


CACHE_TTL = 15 * 60  # 15 minutes


class MsGraph:

    _instance = None

    @classmethod
    def create(cls, config: dict) -> "MsGraph":
        cls._instance = MsGraph(config)
        return cls._instance

    @classmethod
    def get(cls) -> "MsGraph":
        if not cls._instance:
            raise ValueError("MsGraph not initialized")
        return cls._instance

    def __init__(self, config: dict):
        # Get values from environment variables
        self._full_config = config
        self._config = config
        self._tenant_id = self._config["ms_graph_tenant_id"]
        self._client_id = self._config["ms_graph_client_id"]
        self._client_secret = self._config["ms_graph_client_secret"]
        self._user_cache = {}

        # Create a credential object. Used to authenticate requests
        credential = ClientSecretCredential(
            tenant_id=self._tenant_id,
            client_id=self._client_id,
            client_secret=self._client_secret,
        )
        scopes = ["https://graph.microsoft.com/.default"]

        # Create an API client with the credentials and scopes
        self.client = GraphServiceClient(credentials=credential, scopes=scopes)

        # Create a persistent event loop
        self.loop = asyncio.new_event_loop()
        asyncio.set_event_loop(self.loop)

    def get_user_role_assignments(self, user_email: str):
        user_info = self._user_cache.get(user_email)
        if user_info:
            last_fetch = user_info.get("last_fetch")
            if (datetime.datetime.now() - last_fetch).total_seconds() < CACHE_TTL:
                return user_info.get("role_assignments")

        # Define an async function to get the role assignments
        async def fetch_role_assignments():
            result = await self.client.users.by_user_id(
                user_email
            ).app_role_assignments.get()
            resources = [
                {"name": assignment.resource_display_name, "id": assignment.resource_id}
                for assignment in result.value
            ]
            return resources

        # Run the async function using the persistent event loop
        result = self.loop.run_until_complete(fetch_role_assignments())

        self._user_cache[user_email] = {
            "role_assignments": result,
            "last_fetch": datetime.datetime.now(),
        }
        return result

    def __del__(self):
        # Close the event loop when the instance is being destroyed
        if hasattr(self, "loop") and self.loop.is_running():
            self.loop.close()
