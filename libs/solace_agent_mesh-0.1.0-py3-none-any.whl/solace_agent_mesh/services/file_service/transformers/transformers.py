import json
import yaml
import csv
from typing import List, Union, Any
import jq

from solace_ai_connector.common.log import log
from ..file_service_constants import FS_PROTOCOL


# Helper function to convert strings to numbers where applicable
def __convert_to_number(value: str) -> Union[str, int, float]:
    """
    Convert a string to a number if possible.
    """
    try:
        if value.isdigit():
            return int(value)
        elif value.replace(".", "", 1).isdigit():
            return float(value)
        else:
            return value
    except ValueError:
        return value  # Return the original value if it can't be converted to a number


def resolveJq(data: str, mime_type: str, query: str) -> Any:
    """
    Resolve a jq query in a dictionary or list-like structure.

    Parameters:
    - data (str): A string of JSON or YAML content.
    - mime_type (str): The MIME type of the input data ('application/json' or 'application/x-yaml').
    - query (str): The jq query to resolve, e.g., '.item1 .item2'.

    Returns:
    - any: The value at the specified jq query.

    Raises:
    - ValueError: If the mime_type is invalid or the query cannot be resolved.
    - ValueError: If the query is invalid.
    """
    # Parse data based on mime_type
    if mime_type == "application/json":
        parsed_data = json.loads(data)
    elif mime_type == "application/x-yaml" or mime_type == "application/yaml":
        parsed_data = yaml.safe_load(data)
    elif mime_type == "text/csv":
        raw_data = list(csv.DictReader(data.splitlines()))
        parsed_data = _convert_numeric_fields_in_data(raw_data)
    else:
        raise ValueError(
            "Invalid mime_type. Only 'application/json' and 'application/x-yaml' are supported."
        )

    # remove quotes from the query
    if query.startswith("'") and query.endswith("'"):
        query = query[1:-1]

    # Resolve the jq query
    try:
        results = jq.compile(query).input(parsed_data).all()
        output = (
            "\n".join(map(str, results)) if isinstance(results, list) else str(results)
        )
        return output
    except Exception as e:
        raise ValueError(f"Invalid jq query: {query}") from e

def _convert_numeric_fields_in_data(rows: list) -> list:
    """
    Loop over the rows in the data and convert numeric fields to numbers.
    """
    return [{key: __convert_to_number(value) for key, value in row.items()} for row in rows]

def selectColumns(
    csv_file: str,
    columns: List[str],
    header_row=None,
    includeHeaders=False,
    csv_to_array=False,
) -> str:
    """
    Select columns from a list of dictionaries.

    Parameters:
    - csv_file (str): A string of CSV data.
    - columns (List[str]): A list of column names to select.
    - includeHeaders (bool): Whether to include headers in the result.

    Returns:
    - str: A new CSV string with only the selected columns.
    """
    # Parse the CSV string
    csv_lines = csv_file.splitlines()
    if header_row and header_row != csv_lines[0]:
        csv_lines.insert(0, header_row)

    csv_reader = csv.DictReader(csv_lines)

    # Collect rows for the selected columns
    selected_data = []

    if includeHeaders:
        # Include headers in the result
        selected_data.append([col for col in columns])

    for row in csv_reader:
        selected_row = [__convert_to_number(row[col]) for col in columns]
        selected_data.append(selected_row)

    if csv_to_array:
        # If only one column was selected, return a single-dimensional array
        if len(columns) == 1:
            return [row[0] for row in selected_data]

        return selected_data
    else:
        # Convert result back to CSV string
        output = []
        for line in selected_data:
            output.append(",".join(map(str, line)))

        return "\n".join(output)


def limitRows(
    data: list | str, start: int | str = 0, count: int | str = None
) -> list | str:
    """
    Limit the number of rows in a list based on the start and count parameters.
    For list objects, the first `limit` rows are returned.
    For text files, the first `limit` lines are returned.

    Parameters:
    - data (list|str): The input data to l
    imit.
    - start (int|str): The starting index of the data to return.
    - count (int|str): The number of rows to return.

    Returns:
    - list|str: The limited data.
    """
    if type(start) == str:
        start = int(start)
    if type(count) == str:
        count = int(count)

    end = start + count if count and start else count

    if type(data) == list:
        return data[start:end]
    else:
        # text file
        return "\n".join(data.splitlines()[start:end])


class LimitRowsTransformer:
    is_binary_transformer = False
    is_text_transformer = True

    description = f"""
For CSV files, there are:
    - `columns` parameter, this is a list of column names to load.
    For example: `<url>{FS_PROTOCOL}://dcd80258-22f4-4274-bf72-7c45e7b8819b_reports.csv?columns=["col1", "col2", "col3"]</url>`
    - `includeHeaders` parameter, this is a boolean to include headers when selecting columns. (default is false)
    - `csvToArray` parameter, this is a boolean to return the data as an array. (default is false)
    For example: `<url>{FS_PROTOCOL}://dcd80258-22f4-4274-bf72-7c45e7b8819b_reports.csv?columns=["col1", "col2"]&csvToArray=true&resolve=true</url>`
    - `start` parameter, this is the starting index of the data to load. start does not consider header row (`start` on text files will skip the first `start` lines). default is 0
    For example: `{FS_PROTOCOL}://5982e7db-a276-4590-9294-0d89a3439dcc_annual_sale.csv?start=3` # Includes header row + data starting from row 3
    - `count` parameter, this is the max number of rows to load after the start index. (`count` on text files will return the next `count` lines). Can be used without `start` to load the first `count` rows.
    For example: `{FS_PROTOCOL}://e16b46b4-5169-4f48-882f-52c23058ec3c_sales.csv?count=5`
    example 2 (pagination): `{FS_PROTOCOL}://691748f7-bbf6-4b5d-878d-4ff50f085d48_employee_info.csv?start=2&count=10`
    """

    examples = [
        f"""
For example if an agent expects an JSON object with a key `data`, and array values for `x` and `y`, the assistant can use the following response:
{{
    "data": {{
    "x": <url>{FS_PROTOCOL}://285a635c-6812-420e-9766-7347b4c86adc_data.csv?resolve=true?columns=[\"x\"]&csvToArray=true&count=10</url>,
    "y": <url>{FS_PROTOCOL}://1e547b79-110a-4d86-9803-21757e195f0a_data.csv?resolve=true?columns=[\"y\"]&csvToArray=true&count=10</url>
    }}
}}
        """,
        f"""
For example, the URL to retrieve the top 10 rows with columns id and lastname in CSV form from the example file would be:
`<url>{FS_PROTOCOL}://cabfbb23-f27a-45b5-8256-a64425654175_employee_info.csv?columns=["id", "lastname"]&count=10</url>`
        """,
        f"""
Example:

Thanks for your request. Here is your file:
<{{tp}}file name="data_chart.csv" mime_type="text/csv">
    <url>{FS_PROTOCOL}://5d616d36-1bf3-4e5b-8feb-e17f3161b0fe_data_chart.csv?columns=["col1", "col2", "col3"]</url>
</{{tp}}file>
    """,
    ]

    queries = {
        "start": {
            "type": "int",
            "description": "The starting index of the data to load.",
        },
        "count": {
            "type": "int",
            "description": "The max number of rows to load after the start index.",
        }
    }
    
    @staticmethod
    def transform(file:bytes, data: list | str,  transformations: dict, other:dict) -> list | str:
        if transformations.get("start") or transformations.get("count"):
            try:
                start = transformations.get("start", 0)
                count = transformations.get("count", None)
                data = limitRows(data, start, count)
            except Exception as e:
                log.error("Failed to limit rows: %s", e)
                return file
        return data   

class JQTransformer:
    is_binary_transformer = False
    is_text_transformer = True

    description = f"""
For Yaml, CSV, and JSON files, there's `jq` parameter, this supports all the functionalities of `jq` and applies it to the file. 
    If the expression has space, wrap in <url> tags. Converting a CSV would result in an array of object with header keys.
    Don't use backslash (\\) to escape double quotes (") in the expression.

    For example: `{FS_PROTOCOL}://351ea95e-adc2-4a5b-be81-d76137652e26_inventory.json?jq=.item1.item2[0:3][].item3`
    example 2 (selecting and counting): `<url>{FS_PROTOCOL}://cc140ed8-7558-422b-b53b-e754bac8f4db_service_status.json?jq=[.[] | select(.status == "open")] | length</url>`
"""
    examples = [
f"""
Example:

Thanks for your question, I found <url>{FS_PROTOCOL}://f4ec5188-4cdb-4d78-9b20-6c1638b4c5ee_results.json?resolve=true&jq=.items | map(select(.condition == "running")) | length</url> results for you. Here's the report

<{{tp}}file name="results.csv" mime_type="text/csv">
    <url>{FS_PROTOCOL}://f4ec5188-4cdb-4d78-9b20-6c1638b4c5ee_results.json?resolve=true&jq=["names", "id"], (.items[] | select(.condition == "running") | [.name, .id]) | @csv</url>
</{{tp}}file>
""",

f"""
Example: 

Here's your report in HTML format:
<{{tp}}file name="report.html" mime_type="text/html">
    <data>
        <!DOCTYPE html>
        <html>
        <head>
        <title>Report</title>
        </head>
        <body>
        <h1>Report</h1>
        <img src="{FS_PROTOCOL}://ef918fc2-f6e3-4600-8f86-7d8f07a2f7ad_chart.png?encoding=datauri&resolve=true" alt="Report charts">
        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <url>{FS_PROTOCOL}://47232d19-33d0-4505-acb7-51d6eed0611f_results_506429.csv?resolve=true&jq=.[] | ["<tr><td>", .name, "</td><td>", .status, "</td></tr>"] | join("")</url>
            </tbody>
        </table>
        </body>
        </html>        
    </data>
</{{tp}}file>"""
    ]

    queries = {
        "jq": {
            "type": "str",
            "description": "The jq query to resolve, e.g., '.item1 .item2'.",
        },
    }
    
    @staticmethod
    def transform(file:bytes, data: list | str,  transformations: dict, other: dict) -> list | str:
        if transformations.get("jq"):
            try:
                data = resolveJq(data, other.get("mime_type"), transformations["jq"])
            except Exception as e:
                log.error("Failed to resolve jq: %s", e)
                return file
        return data   



class CSVTransformer:
    is_binary_transformer = False
    is_text_transformer = True

    description = ""
    examples = []

    queries = {
        "columns": {
            "type": "list",
            "description": "A list of column names to select.",
        },
        "includeHeaders": {
            "type": "bool",
            "description": "Whether to include headers in the result.",
        },
        "csvToArray": {
            "type": "bool",
            "description": "Whether to convert the result to an array.",
        },
    }
    
    @staticmethod
    def transform(file:bytes, data: list | str,  transformations: dict, other: dict) -> list | str:
        if transformations.get("columns"):
            decoded_data = file.decode("utf-8") if isinstance(file, bytes) else file
            try:
                include_headers = transformations.get("includeHeaders", False)
                csv_to_array = transformations.get("csvToArray", False)
                include_headers = (
                    include_headers
                    if isinstance(include_headers, bool)
                    else include_headers.lower() == "true"
                )
                header_row = decoded_data.splitlines()[0]
                data = selectColumns(
                    data,
                    json.loads(transformations["columns"]),
                    header_row,
                    include_headers,
                    csv_to_array,
                )
            except Exception as e:
                log.error("Failed to select columns: %s", e)
                return file
        return data   


