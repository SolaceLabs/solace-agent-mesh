from typing import List, Set
from .base_authorization_provider import BaseAuthorizationProvider
from ....common.people.ms_graph import MsGraph


class MsGraphProvider(BaseAuthorizationProvider):
    def __init__(self, config: dict):
        super().__init__(config)
        self.ms_graph = MsGraph.create(self.configuration)

    def get_scopes(self, identity: str) -> List[str]:
        """Returns scopes for the given identity based on their roles."""
        roles = set(self.get_roles(identity)) | set(self.base_roles)
        scopes: Set[str] = set()

        for role in roles:
            scopes.update(self.role_to_scope_mappings.get(role, []))

        return list(scopes)

    def get_roles(self, identity: str) -> List[str]:
        """Returns roles for the given identity using MS Graph."""
        role_assignments = self.ms_graph.get_user_role_assignments(identity)
        return [assignment["name"] for assignment in role_assignments]

    def get_authorization_field(self) -> str:
        return self.authorization_field