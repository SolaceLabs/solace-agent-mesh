from typing import List
from .base_authorization_provider import BaseAuthorizationProvider


class PermissiveProvider(BaseAuthorizationProvider):
    def __init__(self, config: dict):
        super().__init__(config)

    def get_scopes(self, identity: str) -> List[str]:
        """Returns a wildcard scope for any identity."""
        return ["*:*:*"]
    def get_roles(self, identity: str) -> List[str]:
        """Returns an 'admin' role for any identity."""
        return ["admin"]

    def get_authorization_field(self) -> str | None:
        """Returns None since permissive authorizer doesn't need an authorization field"""
        return None