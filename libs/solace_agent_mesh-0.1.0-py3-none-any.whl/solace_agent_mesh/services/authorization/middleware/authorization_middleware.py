from ...common.singleton import SingletonMeta
from copy import deepcopy

from ..providers.base_authorization_provider import BaseAuthorizationProvider
from ....services.middleware_service.middleware_service import MiddlewareService

DEFAULT_SCOPES = BaseAuthorizationProvider.PERMISSIVE_SCOPES

class AuthorizationMiddleware(metaclass=SingletonMeta):

    def __init__(self, is_authorized_fn):
        super().__init__()
        self._is_authorized_fn = is_authorized_fn
        _middleware_service = MiddlewareService()
        self._register_middleware(_middleware_service)

    def _register_middleware(self, middleware_service):
        middleware_service.register("filter_action", self._filter_authorized_actions)
        middleware_service.register("validate_action_request", self._validate_action_request)
        middleware_service.register("base_agent_filter", self._is_action_authorized)

    def _validate_action_request(self, user_properties, action_details):
        if not action_details:
            return False
        required_scopes = action_details.get("required_scopes", DEFAULT_SCOPES)
        originator_scopes = user_properties.get("originator_scopes", [])
        return self._is_authorized_fn(originator_scopes, required_scopes)

    def _is_action_authorized(self, user_properties, action):
        required_scopes = action.required_scopes or DEFAULT_SCOPES
        originator_scopes = user_properties.get("originator_scopes", [])
        return self._is_authorized_fn(originator_scopes, required_scopes)
    
    def _filter_authorized_actions(self, user_properties, actions):
        originator_scopes = user_properties.get("originator_scopes", [])
        authorized_actions = []

        for action in actions:
            if action is None:
                continue

            for action_name, action_obj in action.items():
                required_scopes = action_obj.get(
                    "required_scopes", DEFAULT_SCOPES
                )
                if self._is_authorized_fn(originator_scopes, required_scopes):
                    authorized_action = deepcopy(action_obj)
                    authorized_action.pop("required_scopes", None)
                    authorized_actions.append({action_name: authorized_action})

        return authorized_actions
