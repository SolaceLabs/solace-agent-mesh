"""Authorization Component for handling authorization requests."""

from typing import Dict, Any, List
from solace_ai_connector.components.component_base import ComponentBase
from solace_ai_connector.common.message import Message
from ..providers.base_authorization_provider import BaseAuthorizationProvider
from ..providers.permissive_provider import PermissiveProvider
from ..middleware.authorization_middleware import AuthorizationMiddleware

info = {
    "class_name": "AuthorizationComponent",
    "description": "Component that handles authorization requests",
    "config_parameters": [
        {
            "name": "type",
            "type": "string",
            "default": "permissive",
            "description": "Authorization provider type"
        },
        {
            "name": "configuration",
            "type": "object",
            "description": "Authorization provider configuration",
        },
    ],
    "input_schema": {
        "type": "object",
        "properties": {
            "identity": {"type": "string"},
            "request": {
                "type": "string",
                "enum": ["get_scopes", "get_roles", "get_authorization_field"],
            },
        },
        "required": ["identity", "request"],
    },
    "output_schema": {
        "type": "object",
        "properties": {
            "scopes": {"type": "array", "items": {"type": "string"}},
            "roles": {"type": "array", "items": {"type": "string"}},
            "authorization_field": {"type": "string"},
        },
    },
}


class AuthorizationComponent(ComponentBase):
    """Component that handles authorization requests."""

    def __init__(self, **kwargs):
        super().__init__(info, **kwargs)
        self.provider = self._initialize_provider()
        AuthorizationMiddleware(is_authorized_fn=self.is_authorized)

    def _initialize_provider(self) -> BaseAuthorizationProvider:
        """Initialize the authorization provider based on config."""
        self.provider_type = self.get_config("type", "permissive")

        config = {
            "base_roles": self.get_config("base_roles", ["least_privileged_user"]),
            "role_to_scope_mappings": self.get_config(
                "role_to_scope_mappings",
                {"least_privileged_user": BaseAuthorizationProvider.NO_SCOPES},
            ),
            "key_field": self.get_config("key_field", "user_info.email"),
            "configuration": self.get_config("configuration", {}),
        }

        if self.provider_type == "msgraph":
            from ..providers.msgraph_provider import MsGraphProvider
            return MsGraphProvider(config)
        return PermissiveProvider(config)

    def invoke(self, message: Message, data: Dict[str, Any]) -> Dict[str, Any]:
        """Handle authorization requests."""
        user_properties = message.get_user_properties() or {}

        # Get identity from user properties using key_field
        key_parts = self.provider.authorization_field.split('.')
        current_obj = user_properties
        for part in key_parts[:-1]:  # Navigate through nested objects
            current_obj = current_obj.get(part, {})
        identity = current_obj.get(key_parts[-1])

        if not identity and self.provider_type != "permissive":
            raise ValueError(f"Could not find identity using key field: {self.provider.authorization_field}")

        # Get roles and scopes regardless of request type
        roles = self.provider.get_roles(identity)
        scopes = self.provider.get_scopes(identity)

        # Update user properties with roles and scopes
        user_properties.update({
            "originator_role": roles,
            "originator_scopes": scopes,
        })
        message.set_user_properties(user_properties)
        return data

    @staticmethod
    def is_authorized(originator_scopes: List[str], agent_scopes: List[str]) -> bool:
        """Check if the originator's scopes authorize access to the agent's scopes."""
        return BaseAuthorizationProvider.is_authorized(originator_scopes, agent_scopes)
